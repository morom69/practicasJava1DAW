/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package secuencianwhite;

import java.util.Scanner;

/**
 *
 * @author migue
 */
public class SecuenciaNWhite {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n = 0;
        int min = 0;
        int max = 0;
        System.out.println("CÁLCULO SECUENCIA NWHITE ENTRE 2 Y 5");
        System.out.println("====================================");
        System.out.println();
        do {
            System.out.println("Introduce el valor de la secuencia N entre 2 y 5: ");
            n = leeEntero();
        } while (n < 2 || n > 5);
        System.out.println("Introduce el número inferior del rango de números a calcular la secuencia: ");
        min = leeEntero();
        System.out.println("Introduce el número inferior del rango de números a calcular la secuencia: ");
        do {
            System.out.println("Debe ser mayor que " + min + ": ");
            max = leeEntero();
        } while (max <= min);
        System.out.println();
        for (int i = min; i <= max; i++) {
            //calculo secuencia
            if (perteneceSecuenciaNWhite(i, n)) {
                System.out.println(i);
            }
        }
    }

    public static boolean perteneceSecuenciaNWhite(int numero, int n) {
        boolean esNWhite = false;

        Scanner lectura = new Scanner(System.in);
        long numPotencia = 0;
        String numPotenciaTxt = "";
        String numAux;
        int acumulador = 0;

        //Para calcular la potencia de N utilizaremos la función Math.pow() 
        //que devuelve un valor double. A este valor le haremos un casting para 
        //convertirlo a tipo long. Si se hace con int se perderá precisión.
        numPotencia = (long) (Math.pow(numero, n));

        //convertimos a tipo cadena
        numPotenciaTxt = String.valueOf(numPotencia);

        for (int i = numPotenciaTxt.length() / n; i > 0; i--) {
            //hacemos el bucle tantas veces como bloques de N dígitos formen el número
            numAux = "";
            for (int j = 1; j <= n; j++) {
                //componemos cada bloque de N dígitos
                numAux = numPotenciaTxt.charAt(numPotenciaTxt.length() % n + n * i - j) + numAux;
            }
            acumulador += Integer.valueOf(numAux);
        }
        if (numPotenciaTxt.length() % n > 0) {
            //calculamos el bloque final si sobra un bloque más pequeño de N dígitos
            numAux = "";
            for (int i = 1; i <= numPotenciaTxt.length() % n; i++) {
                numAux = numPotenciaTxt.charAt(numPotenciaTxt.length() % n - i) + numAux;
            }
            acumulador += Integer.valueOf(numAux);
        }
        if (acumulador == numero) {
            esNWhite = true;
        }
        return esNWhite;
    }

    public static int leeEntero() {
        Scanner teclado = new Scanner(System.in);
        int entero;
        do {
            System.out.println("Introduzca un valor entero positivo: ");
            while (!teclado.hasNextInt()) {
                teclado.next();
                System.out.println("El valor introducido no es un entero positivo, vuelva a intentarlo: ");
            }
            entero = teclado.nextInt();
        } while (entero < 0);
        return entero;
    }
}
