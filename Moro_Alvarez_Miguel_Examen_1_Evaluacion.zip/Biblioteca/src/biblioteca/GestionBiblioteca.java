/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.util.Scanner;

/**
 *
 * @author migue
 */
public class GestionBiblioteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner lectura = new Scanner(System.in);
        int opcion, posicion; //Guardaremos la opcion del usuario
        Pila p = new Pila();
        String titulo, autor, isbn;
        do {
            System.out.println();
            System.out.println("APLICACIÓN DE GESTIÓN DE BIBLIOTECA");
            System.out.println("===================================");
            System.out.println();
            System.out.println("1.Nuevo Libro");
            System.out.println("2.Sacar Libro");
            System.out.println("3.Salir");

            while (!lectura.hasNextInt()) { //validación de que para la opción de menú se introduce un valor numérico
                lectura.next();
                System.out.println("Debe introducir un valor numérico entre 1 y 3: ");
            }
            opcion = lectura.nextInt();
            lectura.skip("\n"); //se utiliza para evitar que la próxima vez salte la línea al interpretar el enter de la lectura anterior

            switch (opcion) {
                case 1: // 1.nuevo libro
                    // verificamos si hay alguna posición libre en el array de Libros
                    if (p.isFull()) {
                        System.out.println("La pila está llena, no se puede insertar libro");
                    } else {
                        System.out.println("Introduzca el titulo: ");
                        while (!lectura.hasNext()) { //se valida que haya una entrada
                            System.out.println("Debe introducir el titulo: ");
                            lectura.nextLine();
                        }
                        titulo = lectura.nextLine();

                        System.out.println("Introduzca el autor: ");
                        while (!lectura.hasNext()) { //se valida que haya una entrada
                            System.out.println("Debe introducir el autor: ");
                            lectura.nextLine();
                        }
                        autor = lectura.nextLine();

                        do {
                            System.out.println("Introduzca el ISBN (de 10 o 13 caracteres): ");
                            while (!lectura.hasNext()) { //se valida que haya una entrada
                                System.out.println("Debe introducir el ISBN entre 10 y 13 caracteres: ");
                                lectura.nextLine();
                            }
                            isbn = lectura.nextLine();
                        } while (!Libro.compruebaIsbn10(isbn) || !Libro.compruebaIsbn13(isbn));
                        
                        Libro l = new Libro(autor, titulo, isbn);
                        p.push(l);
                    }

                    break;
                case 2: // 2.sacar libro
                    if (p.isEmpty()) {
                        System.out.println("La pila está vacía, no se puede sacar libro");
                    } else {
                        Libro l = new Libro("","","");
                        l = p.pop();
                        l.toString();
                    }

                    break;
                case 3: // 3.salir
                    break;
            }

        } while (opcion
                != 3);
    }
}
