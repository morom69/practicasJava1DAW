/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

/**
 *
 * @author migue
 */
public class Libro {

    private String titulo;
    private String autor;
    private String isbn;

    public Libro(String titulo, String autor, String isbn) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setIsbn(String isbn) {

        this.isbn = isbn;
    }

    public String toString() {
        String datos = "Titulo: " + this.titulo + "; Autor: " + this.autor + "; ISBN: " + this.isbn;
        return datos;
    }
    
    public static boolean compruebaIsbn10(String isbn){
        return true;
    }
    
    public static boolean compruebaIsbn13(String isbn){
        return true;
    }
}
