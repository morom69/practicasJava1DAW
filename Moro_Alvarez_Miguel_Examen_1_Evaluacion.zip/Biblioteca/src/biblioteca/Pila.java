/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

/**
 *
 * @author migue
 */
public class Pila {

    private Libro[] pila;
    private int cabecera;

    public Pila() {
    pila = new Libro[100];
    cabecera  = 0;
}

public boolean push(Libro libro) {
        if (cabecera < 100) {
            pila[cabecera] = libro;
            cabecera = cabecera + 1;
            return true;
        } else {
            return false;
        }
    }

    public Libro pop() {
        if (cabecera == 0) {
            return null;
        } else {
            cabecera = cabecera - 1;
            return pila[cabecera + 1];
        }
    }

    public boolean isEmpty() {
        if (cabecera == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isFull() {
        if (cabecera == 99) {
            return true;
        } else {
            return false;
        }
    }

}
