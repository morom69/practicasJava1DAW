package UD4;


public class Moto {    
    
    private String modelo;
    private int numeroRuedas;
    private int cilindrada;
    private int velocidadMaxima;
    private int peso;
    private String color;
    private int precio;
    private int stock;//Cantidad de motos de las que se disponen

    public Moto(String modelo, String color, int stock) {
        this.modelo = modelo;
        this.color = color;
        this.stock = stock;
    }    
    
    public void comprar(int cantidad) throws Exception{
        if (cantidad<0)
            throw new Exception("No se puede comprar un nº negativo de motos");
        stock = stock + cantidad;
    }
}
